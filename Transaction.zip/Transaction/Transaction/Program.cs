﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop;
using System.Threading;




namespace Transaction
{
    class Program
    {
        Dictionary<string, float> bank;
        Dictionary<string, float> bankSorted;
        Dictionary<string, float> borrower;
        Dictionary<string, float> borrowerSorted;
        Dictionary<string, float> persons;
        Dictionary<string, float> result;
        String filePath = "C:\\test\\test1.xlsx";

        [STAThread]
        static void Main(string[] args)
        {
            Program program = new Program();
            program.persons = new Dictionary<string, float>();
            program.result = new Dictionary<string, float>();
            System.Threading.Thread.CurrentThread.SetApartmentState(System.Threading.ApartmentState.STA);
            program.getFilePath();
            program.readFromExcel();
            program.optimize();
            program.UpdateExcel();


        }


        public void split()
        {
            bank = new Dictionary<string, float>();

            borrower = new Dictionary<string, float>();



            foreach (KeyValuePair<string, float> p in persons)
            {
                if (p.Value > 0)
                {
                    bank[p.Key] = p.Value;
                }
                if (p.Value < 0)
                {
                    borrower[p.Key] = p.Value;
                }
            }
            
        }

        public void sort()
        {
            borrowerSorted = new Dictionary<string, float>();
            bankSorted = new Dictionary<string, float>();

            foreach (KeyValuePair<string, float> b in bank.OrderByDescending(i => i.Value))
            {
                bankSorted[b.Key] = b.Value;
            }
            foreach (KeyValuePair<string, float> b in borrower.OrderBy(i => i.Value))
            {
                borrowerSorted[b.Key] = b.Value;
            }

        }

        public void sattleUp()
        {
  

            foreach (KeyValuePair<string, float> b in bankSorted.OrderByDescending(i => i.Value))
            {
                foreach (KeyValuePair<string, float> bo in borrowerSorted.OrderBy(i => i.Value))
                {
                    //Console.WriteLine("Bank: " + b.Key + " Ballance: " + b.Value + " kr || Borrower: " +bo.Key+ " Balance: " + bo.Value + " kr");
                    if ((bo.Value * (-1)) >= b.Value)
                    {
                        //Console.WriteLine(bo.Key + " pays " + b.Key + " " + b.Value + "kr");
                        result.Add(bo.Key + " Pays " + b.Key, b.Value);
                        if (persons.ContainsKey(bo.Key))
                            persons.Remove(bo.Key);
                        persons.Add(bo.Key, (bo.Value + b.Value));
                        if (persons.ContainsKey(b.Key))
                            persons.Remove(b.Key);
                        persons.Add(b.Key, 0);
                        break;
                    }
                    if ((bo.Value * (-1)) < b.Value)
                    {
                        //Console.WriteLine(bo.Key + " pays " + b.Key + " " + (bo.Value * (-1)) + "kr");
                        result.Add(bo.Key + " Pays " + b.Key, (bo.Value * (-1)));
                        if (persons.ContainsKey(b.Key))
                            persons.Remove(b.Key);
                        persons.Add(b.Key, (b.Value + bo.Value));

                        if (persons.ContainsKey(bo.Key))
                            persons.Remove(bo.Key);
                        persons.Add(bo.Key, 0);
                        break;
                    }
                    
                }
                break;
            }

            optimize();
        }

        public void optimize()
        {
            split();
            sort();
            while (borrowerSorted.Count > 0)
            {
                sattleUp();
            }
        }


        private void UpdateExcel()
        {
            Microsoft.Office.Interop.Excel.Application oXL = null;
            Microsoft.Office.Interop.Excel._Workbook oWB = null;
            Microsoft.Office.Interop.Excel._Worksheet oSheet = null;

            try
            {
                oXL = new Microsoft.Office.Interop.Excel.Application();
                oWB = oXL.Workbooks.Open(filePath);
                oSheet = String.IsNullOrEmpty("out") ? (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet : (Microsoft.Office.Interop.Excel._Worksheet)oWB.Worksheets["out"];
                int row = 1;
                foreach (KeyValuePair<string, float> res in result.OrderByDescending(i => i.Value))
                {
                    oSheet.Cells[row, 1] = res.Key;
                    oSheet.Cells[row, 2] = res.Value;
                    Console.WriteLine(res.Key + " " + res.Value+" radindex "+row);
                    row++;
                }

                oWB.Save();

                MessageBox.Show("Done!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                if (oWB != null)
                    oWB.Close();
            }
        }
        public void readFromExcel()
        {
            //Create COM Objects. Create a COM object for everything that is referenced
            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(filePath);
            Microsoft.Office.Interop.Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[4];
            Microsoft.Office.Interop.Excel.Range xlRange = xlWorksheet.UsedRange;

            //iterate over the rows and columns and print to the console as it appears in the file
            //excel is not zero based!!
            int colCount = 100;
            int j=1;

            while (j <= colCount)
            {

                //write the value to the console
                if (xlRange.Cells[2, j] != null && xlRange.Cells[2, j].Value2 != null)
                {
                    if (xlRange.Cells[1, j] != null && xlRange.Cells[1, j].Value2 != null)
                    {
                        if (xlRange.Cells[2, j].Value2 != 0)
                        {
                            //Console.WriteLine(xlRange.Cells[1, j].Value2);
                            //Console.WriteLine(xlRange.Cells[2, j].Value2);
                            string name = xlRange.Cells[1, j].Value2.ToString();
                            float balance = float.Parse(xlRange.Cells[2, j].Value2.ToString());

                            persons.Add(name, balance);
                        }
                    }
                }
                



                j++;
                //add useful things here!
            }

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad

            //release com objects to fully kill excel process from running in the background
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlRange);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);


        }

        private void getFilePath()
        {
            OpenFileDialog openFD = new OpenFileDialog();

            openFD.InitialDirectory = "c:\\";
            openFD.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFD.FilterIndex = 2;
            openFD.RestoreDirectory = true;

            if (openFD.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    filePath = openFD.FileName;
                    //MessageBox.Show(filePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

    }
}
